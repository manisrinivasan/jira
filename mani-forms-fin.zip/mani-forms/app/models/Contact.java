package models;

import javax.validation.Valid;

import play.data.format.Formats.NonEmpty;
import play.data.validation.Constraints.Email;
import play.data.validation.Constraints.Required;

public class Contact {
    
    @Required
    public String summary;
    
    @Required
    public String description;
    
    public String validate() {
    if (description == "")
    	return "Description is mandatory:";
    else
    	return null;
    }
    
    
    
 	@Required
 	@NonEmpty
 	@Email
    public String email;
    
 	 @Required
     public String company;
     
    public String issueType;
    
    public String persona;
    
    //@Valid
    @Required
    public String project;
    
    public String validate;
    public Contact() {}
    
    public Contact(String summary, String description, String issueType, String project,String persona,String email,String company,String gap) {
        this.summary = summary;
        this.description = description;
        this.issueType = issueType;
        this.project = project;
        this.persona= persona;
        this.email=email;
        this.company=company;
        this.validate=gap;
        
    }
}