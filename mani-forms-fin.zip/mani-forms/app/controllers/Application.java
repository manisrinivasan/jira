package controllers;

import static play.data.Form.form;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import jdk.nashorn.internal.ir.RuntimeNode.Request;
import models.Contact;

import org.apache.commons.codec.binary.Base64;

import play.Play;
import play.data.DynamicForm;
import play.data.Form;
import play.libs.F.Function;
import play.libs.Json;
import play.libs.WS;
import play.libs.WS.WSRequestHolder;
import play.mvc.Controller;
import play.mvc.Result;
import scala.collection.Seq;
import views.html.form;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ning.http.client.Realm.AuthScheme;



public class Application extends Controller {
	
	
  
	/**
     * Defines a form wrapping the Contact class.
     */ 
    final static Form<Contact> contactForm = form(Contact.class);
  
    /**
     * Display a blank form.
     */ 
    public static Result blank() {
        return ok(form.render(contactForm));
    }
  
    public static List<String> projects() {
    	return Arrays.asList(new String[] {
                "OPSC", "DSE", "DOCS", "SEARCH" 
        	}
    	);
    }
     public static List<String> persona() {
    	return Arrays.asList(new String[] {
                "Developer", "Admin", "DevOps", "Others" 
        	}
    	);
   
    
    }
    public static Result edit() {
    	Contact existingContact = new Contact(
                "", "", "",
                "DOCS", null, null, null, null
            );
        return ok(form.render(contactForm.fill(existingContact)));
    }
  
    /**
     * Handle the form submission.
     */
    public static Result submit() {
        Form<Contact> filledForm = contactForm.bindFromRequest();
        /*if(filledForm.hasErrors()) {
            return badRequest(form.render(filledForm));
        } else {
            Contact created = filledForm.get();
            return ok(summary.render(created));
        }*/
         
        if(filledForm.hasErrors()) {
            return badRequest(form.render(filledForm));
        } else 
        
        {
        final byte[] encodeBase64 = Base64.encodeBase64("mani:mani".getBytes());
        final String auth = new String(encodeBase64);
        
            Contact created = filledForm.get();
            ObjectNode fields = Json.newObject();
            ObjectNode project = Json.newObject();
            ObjectNode key = Json.newObject();
            ObjectNode issueType = Json.newObject();
            issueType.put("name", "New Feature");
            key.put("key", created.project);
            project.put("project", key);
            project.put("summary", created.summary);
            project.put("description",created.email+":"+created.company+":"+ created.description);
            project.put("issuetype",issueType );
            fields.put("fields", project);
            System.out.println("ObjectNode: " + fields.toString());
           // System.out.println("gap is "+created.gap);
            WS.url("https://www.google.com/recaptcha/api/siteverify")
            .setQueryParameter("secret", "6LemHgETAAAAAOc7c1p3UmOqbOql7rP8ytAjTb8g")
            .setQueryParameter("response", created.validate)
            .post("content").map(
            	    new Function<WS.Response, Result>() {
            	        @SuppressWarnings("deprecation")
						public Result apply(WS.Response response) {
            	           
            	          if(response.getStatus() >=200 && response.getStatus() <300 && response.getBody().contains("true")) {
               	          // System.out.println(String.format("[statusCode=%d; statusText=%s; responseText=%s]", response.getStatus(), response.getStatusText(), response.getBody()));
               	        final String url = Play.application().configuration().getString("jiraURL");
               	     //   System.out.println("variable is"+ Play.application().configuration().getString("appresponse"));
                        WSRequestHolder request = WS.url(url);
                        request.setAuth("mani", "mani", AuthScheme.BASIC);
                        request.setHeader("Accept", "application/json");
                        request.setHeader("Content-Type", "application/json");
                        
                        return async(
                        		request.post(fields.toString()).map(
                        	    new Function<WS.Response, Result>() {
                        	        public Result apply(WS.Response response) {
                        	           System.out.println(String.format("[statusCode=%d; statusText=%s; responseText=%s]", response.getStatus(), response.getStatusText(), response.getBody()));
                        	           
                        	          if(response.getStatus() >=200 && response.getStatus() <300) {
                           	           System.out.println(String.format("[statusCode=%d; statusText=%s; responseText=%s]", response.getStatus(), response.getStatusText(), response.getBody()));

                        	           		flash("success", "This is a success");

                        	           } else {
                            	           System.out.println(String.format("Fail [statusCode=%d; statusText=%s; responseText=%s]", response.getStatus(), response.getStatusText(), response.getBody()));

                        	           		flash("Fail", "There is an issue"+ response.getStatusText());

                        	        	   //status(response.getStatus());
                        	           }
                          	          return redirect(routes.Application.index()); 
                        	           
                        	        }
                        	    }
                        	)
                            );
            	           } else {
            	           	 flash("Bot! failed validation", "There is an issue"+ response.getStatusText());
                 	          return redirect(routes.Application.index()); 

            	        	   //status(response.getStatus());
            	           }
            	           
            	        }
            	        
            	    }
            	    
            	);

            
            
          
        }
   		flash("failed validation", "There is an issue");

         return redirect(routes.Application.index()); 
    }
    
    public static Result index() {
    	return blank();
    }
  
}